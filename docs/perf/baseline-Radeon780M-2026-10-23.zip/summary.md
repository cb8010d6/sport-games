# Rendered benchmark: PASS

Reference targets: Radeon 780M, 2p 60 fps / 4p 45 fps. Actual devices are recorded per run.
A PASS means valid measurement, independent of the performance target. Every repeat must meet its target.
R7 frame-time percentiles; 1% low = 1000 / mean(slowest ceil(N*0.01) frame ms). GPU null means unavailable.

| Game/map/players/quality | Valid runs | Avg FPS | 1% low | p95 ms | p99 ms | Worst ms | Repeat FPS range | Target |
|---|---:|---:|---:|---:|---:|---:|---|---|
| archery/0/2/2 | 3/3 | 182.85 | 159.98 | 5.72 | 5.93 | 8.86 | 182.24–183.36 | MET |
| archery/0/4/2 | 3/3 | 129.36 | 99.10 | 8.00 | 8.27 | 144.63 | 128.65–129.94 | MET |
| basketball/0/2/2 | 3/3 | 114.29 | 80.55 | 9.14 | 9.47 | 81.45 | 113.15–114.95 | MET |
| basketball/0/4/2 | 3/3 | 92.81 | 73.30 | 11.74 | 12.37 | 45.51 | 90.11–94.57 | MET |
| bowling/0/2/2 | 3/3 | 136.44 | 87.77 | 7.58 | 7.86 | 125.03 | 135.59–136.91 | MET |
| bowling/0/4/2 | 3/3 | 102.41 | 90.08 | 10.15 | 10.54 | 13.27 | 101.91–102.73 | MET |
| plane/0/2/2 | 3/3 | 141.71 | 115.10 | 7.62 | 7.99 | 18.24 | 141.26–142.06 | MET |
| plane/0/4/2 | 3/3 | 97.38 | 81.16 | 11.12 | 11.73 | 16.23 | 96.86–97.83 | MET |
| skate/0/2/2 | 3/3 | 38.08 | 34.98 | 27.41 | 27.78 | 30.70 | 38.06–38.11 | BELOW_TARGET |
| skate/0/4/2 | 3/3 | 23.14 | 19.19 | 46.41 | 49.43 | 57.32 | 22.87–23.60 | BELOW_TARGET |
| ski/0/2/2 | 3/3 | 40.50 | 37.39 | 25.55 | 25.90 | 28.65 | 40.10–40.97 | BELOW_TARGET |
| ski/0/4/2 | 3/3 | 24.50 | 20.48 | 43.37 | 47.10 | 50.88 | 24.03–24.84 | BELOW_TARGET |
